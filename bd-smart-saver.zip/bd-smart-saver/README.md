# 🇧🇩 BD Smart Saver — AI-Powered Price Comparison Platform

A modern, AI-powered price comparison website specifically built for Bangladesh. Helps users find cheaper alternatives, lower prices, and better deals from all major Bangladeshi eCommerce stores.

## 🌟 Features

### Core Features
- **AI-Powered Search** — Search any product in Bangla or English
- **Price Comparison** — Compare prices from 8+ Bangladeshi stores instantly
- **Cheaper Alternatives** — AI suggests similar products at lower prices
- **AI Recommendation System** — Budget-based smart recommendations
- **Deal Detection** — Flash sales, coupons, and discount alerts
- **Price History Graph** — Track price changes over time
- **Fake Discount Detection** — AI flags manipulated pricing
- **Shopping Advisor** — AI tells you whether to buy now or wait

### User Features
- **User Accounts** — Firebase Auth with Google Login
- **Wishlist & Alerts** — Get notified when prices drop
- **Voice Search** — Search in Bangla and English using voice
- **Barcode Scanner** — Scan products to compare prices
- **Review Aggregation** — AI-summarized reviews from multiple stores
- **Location-Based Shopping** — Find nearby physical shops

### Supported Stores
| Store | Products |
|-------|----------|
| Daraz Bangladesh | 15,000+ |
| Star Tech | 8,000+ |
| Ryans Computers | 6,000+ |
| Pickaboo | 5,000+ |
| AjkerDeal | 10,000+ |
| Othoba | 4,000+ |
| BDStall | 3,000+ |
| Gadget & Gear | 2,000+ |

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, Tailwind CSS, Framer Motion |
| Backend | Node.js, Express.js (via Next.js API routes) |
| Database | MongoDB (Mongoose ODM) |
| AI/ML | OpenAI API (GPT-4.1-mini) |
| Authentication | Firebase Auth + Google Login |
| Hosting | Vercel / Cloudflare |

## 📁 Project Structure

```
bd-smart-saver/
├── public/
│   └── images/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── search/route.js
│   │   │   ├── recommendations/route.js
│   │   │   └── deals/route.js
│   │   ├── search/page.js
│   │   ├── product/page.js
│   │   ├── deals/page.js
│   │   ├── categories/page.js
│   │   ├── wishlist/page.js
│   │   ├── admin/page.js
│   │   ├── layout.js
│   │   └── page.js
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.js
│   │   │   ├── Footer.js
│   │   │   └── MobileNav.js
│   │   ├── home/
│   │   │   ├── HeroSection.js
│   │   │   ├── SearchSection.js
│   │   │   ├── TrendingDeals.js
│   │   │   ├── CheapestToday.js
│   │   │   ├── AIRecommendations.js
│   │   │   ├── PopularCategories.js
│   │   │   ├── PriceDropAlerts.js
│   │   │   └── StoresSection.js
│   │   └── common/
│   │       └── ProductCard.js
│   ├── lib/
│   │   ├── firebase.js
│   │   ├── mongodb.js
│   │   └── openai.js
│   ├── hooks/
│   │   └── useAuth.js
│   ├── context/
│   │   └── ThemeContext.js
│   └── styles/
│       └── globals.css
├── .env.example
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
├── package.json
└── README.md
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)
- Firebase project
- OpenAI API key

### Installation

1. **Clone the project:**
   ```bash
   cd bd-smart-saver
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Set up environment variables:**
   ```bash
   cp .env.example .env.local
   # Edit .env.local with your credentials
   ```

4. **Set up Firebase:**
   - Go to [Firebase Console](https://console.firebase.google.com/)
   - Create a project
   - Enable Authentication (Email/Password + Google)
   - Copy config to `.env.local`

5. **Set up MongoDB:**
   - Create a [MongoDB Atlas](https://www.mongodb.com/atlas) cluster
   - Add connection string to `.env.local`

6. **Set up OpenAI:**
   - Get API key from [OpenAI](https://platform.openai.com/)
   - Add to `.env.local`

7. **Run development server:**
   ```bash
   npm run dev
   ```

8. **Open browser:**
   - Navigate to `http://localhost:3000`

### Build for Production
```bash
npm run build
npm start
```

### Deploy to Vercel
```bash
npx vercel
```

## 🎨 Design System

### Color Palette
| Color | Hex | Usage |
|-------|-----|-------|
| Primary Green | `#00C853` | CTAs, links, highlights |
| Secondary Dark | `#0D1117` | Dark mode background |
| Accent Yellow | `#FFD600` | Badges, ratings, alerts |
| White | `#FFFFFF` | Light mode background |

### Theme
- Dark + Light mode toggle
- Mobile-first responsive design
- Framer Motion animations
- Glass morphism effects
- Gradient accents

## 🤖 AI Features (OpenAI Integration)

1. **Smart Match** — Compares specs to find cheaper products with similar quality
2. **Budget Assistant** — User enters budget, AI finds best options
3. **Fake Discount Detection** — Detects inflated original prices
4. **Shopping Advisor** — Recommends buy now vs. wait
5. **Review Summarization** — AI summarizes reviews from multiple stores

## 📊 Admin Panel

- Dashboard with analytics
- Product management
- Store management
- User management
- Price scraper controls
- AI settings configuration

## 🔮 Future Features

- Mobile app (Android & iOS)
- AI chatbot shopping assistant
- Cashback system
- Local market price comparison
- AI-generated buying guides

## 📱 Pages

| Page | Route | Description |
|------|-------|-------------|
| Home | `/` | Hero, search, deals, categories |
| Search | `/search` | Product search results |
| Product | `/product` | Price comparison detail |
| Deals | `/deals` | Flash deals & coupons |
| Categories | `/categories` | Browse by category |
| Wishlist | `/wishlist` | Price drop alerts |
| Admin | `/admin` | Admin dashboard |

## 🎯 Target Users

- Students looking for affordable tech
- Gamers comparing peripheral prices
- Online shoppers seeking best deals
- Tech enthusiasts tracking prices
- Budget-conscious buyers in Bangladesh

---

Built with ❤️ for Bangladesh | বাংলাদেশের জন্য তৈরি
