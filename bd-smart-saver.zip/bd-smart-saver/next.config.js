/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['images.daraz.com.bd', 'www.startech.com.bd', 'www.ryanscomputers.com'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  experimental: {
    serverActions: true,
  },
};

module.exports = nextConfig;
