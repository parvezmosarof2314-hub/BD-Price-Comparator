/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#00C853',
          50: '#E8FFF0',
          100: '#B9FFD4',
          200: '#7AFFB0',
          300: '#3BFF8C',
          400: '#00FC6B',
          500: '#00C853',
          600: '#009940',
          700: '#006B2D',
          800: '#003D1A',
          900: '#001F0D',
        },
        secondary: {
          DEFAULT: '#0D1117',
          50: '#F5F6F8',
          100: '#D1D5DB',
          200: '#9CA3AF',
          300: '#6B7280',
          400: '#374151',
          500: '#1F2937',
          600: '#161B22',
          700: '#0D1117',
          800: '#080B0F',
          900: '#030507',
        },
        accent: {
          DEFAULT: '#FFD600',
          50: '#FFFDE5',
          100: '#FFF9B3',
          200: '#FFF380',
          300: '#FFED4D',
          400: '#FFE61A',
          500: '#FFD600',
          600: '#CCB000',
          700: '#998400',
          800: '#665800',
          900: '#332C00',
        },
      },
      fontFamily: {
        sans: ['Inter', 'Noto Sans Bengali', 'sans-serif'],
        bangla: ['Noto Sans Bengali', 'sans-serif'],
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite',
        'slide-up': 'slideUp 0.5s ease-out',
        'slide-down': 'slideDown 0.5s ease-out',
        'fade-in': 'fadeIn 0.5s ease-out',
        'pulse-glow': 'pulseGlow 2s infinite',
        'shimmer': 'shimmer 2s infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        glow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(0, 200, 83, 0.3)' },
          '50%': { boxShadow: '0 0 40px rgba(0, 200, 83, 0.6)' },
        },
        slideUp: {
          from: { transform: 'translateY(20px)', opacity: '0' },
          to: { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          from: { transform: 'translateY(-20px)', opacity: '0' },
          to: { transform: 'translateY(0)', opacity: '1' },
        },
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 5px rgba(0, 200, 83, 0.4)' },
          '50%': { boxShadow: '0 0 20px rgba(0, 200, 83, 0.8)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
    },
  },
  plugins: [],
};
