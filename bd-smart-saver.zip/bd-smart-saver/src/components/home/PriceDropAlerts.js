'use client';

import { motion } from 'framer-motion';

const priceDrops = [
  { id: 1, name: 'AirPods Pro 2nd Gen', oldPrice: 35000, newPrice: 29999, drop: 14, store: 'Pickaboo', time: '2 hours ago', icon: '🎧' },
  { id: 2, name: 'Samsung Galaxy Tab S9', oldPrice: 75000, newPrice: 65000, drop: 13, store: 'Star Tech', time: '4 hours ago', icon: '📱' },
  { id: 3, name: 'Dell Monitor 27" 4K', oldPrice: 45000, newPrice: 38000, drop: 16, store: 'Ryans', time: '6 hours ago', icon: '🖥️' },
  { id: 4, name: 'PS5 DualSense Controller', oldPrice: 8500, newPrice: 7200, drop: 15, store: 'Daraz', time: '8 hours ago', icon: '🎮' },
];

export default function PriceDropAlerts() {
  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="section-title flex items-center gap-2">
            📉 Price Drop Alerts
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Products with recent price drops</p>
        </div>
        <button className="text-sm text-primary font-medium hover:underline">
          Set Alert →
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {priceDrops.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.08 }}
            whileHover={{ scale: 1.02 }}
            className="card p-4 cursor-pointer border-l-4 border-l-green-500"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-50 dark:bg-green-900/20 flex items-center justify-center flex-shrink-0">
                <span className="text-xl">{item.icon}</span>
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-medium text-gray-800 dark:text-gray-200 truncate">{item.name}</h4>
                <p className="text-[10px] text-gray-400">{item.store} • {item.time}</p>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs line-through text-gray-400">৳{item.oldPrice.toLocaleString()}</span>
                  <span className="text-sm font-bold text-primary">৳{item.newPrice.toLocaleString()}</span>
                </div>
                <span className="inline-block mt-1 text-[10px] font-medium text-green-600 bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded-full">
                  ↓ {item.drop}% dropped
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
