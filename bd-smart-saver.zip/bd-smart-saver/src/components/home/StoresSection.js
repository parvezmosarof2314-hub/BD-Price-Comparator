'use client';

import { motion } from 'framer-motion';

const stores = [
  { id: 1, name: 'Daraz', products: '15K+', color: '#F85606', letter: 'D' },
  { id: 2, name: 'Star Tech', products: '8K+', color: '#1E88E5', letter: 'ST' },
  { id: 3, name: 'Ryans', products: '6K+', color: '#E53935', letter: 'R' },
  { id: 4, name: 'Pickaboo', products: '5K+', color: '#43A047', letter: 'P' },
  { id: 5, name: 'AjkerDeal', products: '10K+', color: '#FF6F00', letter: 'AD' },
  { id: 6, name: 'Othoba', products: '4K+', color: '#6A1B9A', letter: 'O' },
  { id: 7, name: 'BDStall', products: '3K+', color: '#00838F', letter: 'BD' },
  { id: 8, name: 'Gadget & Gear', products: '2K+', color: '#2E7D32', letter: 'GG' },
];

export default function StoresSection() {
  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="section-title">Supported Stores</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">We compare prices from all major Bangladeshi eCommerce platforms</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {stores.map((store, index) => (
          <motion.div
            key={store.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            whileHover={{ y: -3 }}
            className="card p-4 text-center cursor-pointer"
          >
            <div
              className="w-12 h-12 mx-auto rounded-xl flex items-center justify-center mb-2"
              style={{ backgroundColor: store.color + '20' }}
            >
              <span className="text-sm font-bold" style={{ color: store.color }}>{store.letter}</span>
            </div>
            <h4 className="text-xs font-medium text-gray-800 dark:text-gray-200">{store.name}</h4>
            <p className="text-[10px] text-gray-400">{store.products} products</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
