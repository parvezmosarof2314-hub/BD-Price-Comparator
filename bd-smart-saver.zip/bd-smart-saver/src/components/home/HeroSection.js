'use client';

import { motion } from 'framer-motion';

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-secondary-700 via-secondary-600 to-secondary-700 dark:from-secondary-800 dark:via-secondary-700 dark:to-secondary-800">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="text-center space-y-6">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-1.5"
          >
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <span className="text-sm text-primary font-medium">AI-Powered Price Comparison</span>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight"
          >
            Save Money on
            <br />
            <span className="gradient-text">Every Purchase</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto"
          >
            Compare prices from 8+ Bangladeshi stores instantly. Get AI-powered recommendations for cheaper alternatives.
          </motion.p>

          {/* Bangla subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="text-base text-gray-500 font-bangla"
          >
            বাংলাদেশের সেরা দামে পণ্য খুঁজুন — AI দিয়ে সস্তা বিকল্প পান
          </motion.p>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex items-center justify-center gap-8 md:gap-12 pt-6"
          >
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white">8+</div>
              <div className="text-xs text-gray-400">Stores</div>
            </div>
            <div className="w-px h-10 bg-secondary-500" />
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white">50K+</div>
              <div className="text-xs text-gray-400">Products</div>
            </div>
            <div className="w-px h-10 bg-secondary-500" />
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white">AI</div>
              <div className="text-xs text-gray-400">Powered</div>
            </div>
            <div className="w-px h-10 bg-secondary-500" />
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-accent">৳</div>
              <div className="text-xs text-gray-400">Best Price</div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" fill="none" className="w-full">
          <path d="M0 60V30C240 10 480 0 720 10C960 20 1200 40 1440 30V60H0Z" className="fill-white dark:fill-secondary-700" />
        </svg>
      </div>
    </section>
  );
}
