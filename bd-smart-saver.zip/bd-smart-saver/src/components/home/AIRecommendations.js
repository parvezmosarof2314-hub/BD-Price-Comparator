'use client';

import { motion } from 'framer-motion';

const recommendations = [
  {
    id: 1,
    searched: 'iPhone 15 Pro',
    searchedPrice: 189999,
    alternatives: [
      { name: 'Samsung Galaxy S24', price: 109999, savings: 80000, match: '92%' },
      { name: 'Google Pixel 8', price: 89999, savings: 100000, match: '88%' },
      { name: 'Nothing Phone 2', price: 59999, savings: 130000, match: '82%' },
    ]
  },
  {
    id: 2,
    searched: 'MacBook Pro M3',
    searchedPrice: 250000,
    alternatives: [
      { name: 'ASUS Zenbook 14', price: 125000, savings: 125000, match: '85%' },
      { name: 'Lenovo ThinkPad X1', price: 145000, savings: 105000, match: '90%' },
      { name: 'HP Spectre x360', price: 135000, savings: 115000, match: '87%' },
    ]
  },
];

export default function AIRecommendations() {
  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="section-title flex items-center gap-2">
            🤖 AI Recommendations
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Cheaper alternatives with similar quality</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {recommendations.map((rec, index) => (
          <motion.div
            key={rec.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="card p-5 space-y-4"
          >
            {/* Searched Product */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-400">You searched for:</p>
                <h4 className="text-sm font-semibold text-gray-800 dark:text-white">{rec.searched}</h4>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-400">Price</p>
                <p className="text-sm font-bold text-gray-600 dark:text-gray-300">৳{rec.searchedPrice.toLocaleString()}</p>
              </div>
            </div>

            <div className="border-t border-gray-100 dark:border-secondary-500 pt-3">
              <p className="text-xs text-primary font-medium mb-3 flex items-center gap-1">
                <span className="w-4 h-4 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-[8px]">AI</span>
                </span>
                Cheaper Alternatives Found:
              </p>

              <div className="space-y-2.5">
                {rec.alternatives.map((alt, i) => (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-xl bg-gray-50 dark:bg-secondary-700 hover:bg-primary/5 dark:hover:bg-primary/5 transition-colors cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <span className="text-xs font-bold text-primary">{alt.match}</span>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-gray-800 dark:text-gray-200">{alt.name}</p>
                        <p className="text-[10px] text-green-500">Save ৳{alt.savings.toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-primary">৳{alt.price.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
