'use client';

import { motion } from 'framer-motion';

const cheapestProducts = [
  { id: 1, name: 'Xiaomi Redmi Note 13', price: 22999, store: 'Daraz', savings: 3000, icon: '📱' },
  { id: 2, name: 'JBL Tune 520BT', price: 4500, store: 'AjkerDeal', savings: 1500, icon: '🎧' },
  { id: 3, name: 'Havit MS752 Mouse', price: 450, store: 'Star Tech', savings: 200, icon: '🖱️' },
  { id: 4, name: 'Anker PowerCore 10000', price: 2800, store: 'Gadget & Gear', savings: 700, icon: '🔋' },
  { id: 5, name: 'Redragon K552 Keyboard', price: 3200, store: 'Ryans', savings: 800, icon: '⌨️' },
];

export default function CheapestToday() {
  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="section-title flex items-center gap-2">
            💰 Cheapest Today
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Lowest prices found by our AI</p>
        </div>
      </div>

      <div className="space-y-3">
        {cheapestProducts.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: index * 0.08 }}
            whileHover={{ scale: 1.01 }}
            className="card p-4 flex items-center gap-4 cursor-pointer"
          >
            {/* Rank */}
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-bold text-primary">#{index + 1}</span>
            </div>

            {/* Icon */}
            <div className="w-12 h-12 rounded-xl bg-gray-50 dark:bg-secondary-700 flex items-center justify-center flex-shrink-0">
              <span className="text-2xl">{product.icon}</span>
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium text-gray-800 dark:text-gray-200 truncate">{product.name}</h4>
              <p className="text-xs text-gray-400">{product.store}</p>
            </div>

            {/* Price */}
            <div className="text-right flex-shrink-0">
              <div className="text-sm font-bold text-primary">৳{product.price.toLocaleString()}</div>
              <div className="text-[10px] text-green-500 font-medium">Save ৳{product.savings.toLocaleString()}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
