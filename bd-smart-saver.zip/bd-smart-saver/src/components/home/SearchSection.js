'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';

export default function SearchSection() {
  const [query, setQuery] = useState('');
  const [isListening, setIsListening] = useState(false);

  const popularSearches = [
    'iPhone 15', 'Gaming Mouse', 'Air Conditioner', 'Laptop', 'Protein Powder',
    'Smart Watch', 'Headphones', 'Power Bank'
  ];

  const handleVoiceSearch = () => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'bn-BD';
      recognition.continuous = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setQuery(transcript);
      };

      recognition.start();
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(query)}`;
    }
  };

  return (
    <section className="relative -mt-8 z-10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="bg-white dark:bg-secondary-600 rounded-2xl shadow-2xl shadow-black/10 dark:shadow-black/30 p-4 md:p-6 border border-gray-100 dark:border-secondary-500"
      >
        {/* Search Form */}
        <form onSubmit={handleSearch} className="flex items-center gap-2">
          <div className="flex-1 relative">
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="m21 21-6-6m2-5a7 7 0 1 1-14 0 7 7 0 0 1 14 0z" />
            </svg>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search any product... (Bangla or English)"
              className="w-full pl-12 pr-4 py-3.5 bg-gray-50 dark:bg-secondary-700 border border-gray-200 dark:border-secondary-500 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all text-sm md:text-base"
            />
          </div>

          {/* Voice Search */}
          <button
            type="button"
            onClick={handleVoiceSearch}
            className={`p-3.5 rounded-xl transition-all ${
              isListening 
                ? 'bg-red-500 text-white animate-pulse' 
                : 'bg-gray-100 dark:bg-secondary-700 text-gray-500 hover:bg-primary/10 hover:text-primary'
            }`}
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z" />
              <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
            </svg>
          </button>

          {/* Barcode Scanner */}
          <button
            type="button"
            className="p-3.5 rounded-xl bg-gray-100 dark:bg-secondary-700 text-gray-500 hover:bg-primary/10 hover:text-primary transition-all hidden sm:block"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
            </svg>
          </button>

          {/* Search Button */}
          <button type="submit" className="btn-primary py-3.5 px-6 text-sm whitespace-nowrap">
            Compare
          </button>
        </form>

        {/* Popular Searches */}
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="text-xs text-gray-400">Popular:</span>
          {popularSearches.map((term) => (
            <button
              key={term}
              onClick={() => setQuery(term)}
              className="text-xs px-3 py-1 rounded-full bg-gray-100 dark:bg-secondary-700 text-gray-600 dark:text-gray-300 hover:bg-primary/10 hover:text-primary transition-colors"
            >
              {term}
            </button>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
