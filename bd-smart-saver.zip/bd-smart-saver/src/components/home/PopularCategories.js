'use client';

import { motion } from 'framer-motion';

const categories = [
  { id: 1, name: 'Smartphones', nameBn: 'স্মার্টফোন', icon: '📱', count: 2450, color: 'from-blue-500 to-purple-500' },
  { id: 2, name: 'Laptops', nameBn: 'ল্যাপটপ', icon: '💻', count: 1230, color: 'from-green-500 to-teal-500' },
  { id: 3, name: 'Headphones', nameBn: 'হেডফোন', icon: '🎧', count: 890, color: 'from-pink-500 to-red-500' },
  { id: 4, name: 'Gaming', nameBn: 'গেমিং', icon: '🎮', count: 670, color: 'from-purple-500 to-indigo-500' },
  { id: 5, name: 'Smart Watch', nameBn: 'স্মার্ট ওয়াচ', icon: '⌚', count: 540, color: 'from-orange-500 to-yellow-500' },
  { id: 6, name: 'Camera', nameBn: 'ক্যামেরা', icon: '📷', count: 320, color: 'from-cyan-500 to-blue-500' },
  { id: 7, name: 'TV & Display', nameBn: 'টিভি', icon: '📺', count: 450, color: 'from-red-500 to-orange-500' },
  { id: 8, name: 'Accessories', nameBn: 'এক্সেসরিজ', icon: '🔌', count: 1800, color: 'from-gray-500 to-gray-700' },
];

export default function PopularCategories() {
  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="section-title flex items-center gap-2">
            📂 Popular Categories
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Browse by category</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {categories.map((category, index) => (
          <motion.div
            key={category.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            whileHover={{ y: -4, scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="card p-4 text-center cursor-pointer group"
          >
            <div className={`w-12 h-12 mx-auto rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center mb-2 group-hover:scale-110 transition-transform`}>
              <span className="text-2xl">{category.icon}</span>
            </div>
            <h4 className="text-xs font-medium text-gray-800 dark:text-gray-200">{category.name}</h4>
            <p className="text-[10px] text-gray-400 font-bangla">{category.nameBn}</p>
            <p className="text-[10px] text-primary mt-1">{category.count}+ items</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
