'use client';

import { motion } from 'framer-motion';
import ProductCard from '../common/ProductCard';

const trendingDeals = [
  {
    id: 1,
    name: 'Samsung Galaxy S24 Ultra',
    image: '📱',
    originalPrice: 159999,
    currentPrice: 139999,
    store: 'Star Tech',
    discount: 12,
    rating: 4.8,
    isHot: true,
  },
  {
    id: 2,
    name: 'Sony WH-1000XM5 Headphones',
    image: '🎧',
    originalPrice: 42000,
    currentPrice: 35500,
    store: 'Ryans Computers',
    discount: 15,
    rating: 4.9,
    isHot: true,
  },
  {
    id: 3,
    name: 'MacBook Air M3 2024',
    image: '💻',
    originalPrice: 175000,
    currentPrice: 162000,
    store: 'Pickaboo',
    discount: 7,
    rating: 4.7,
    isNew: true,
  },
  {
    id: 4,
    name: 'Logitech G Pro X Mouse',
    image: '🖱️',
    originalPrice: 8500,
    currentPrice: 6999,
    store: 'Gadget & Gear',
    discount: 18,
    rating: 4.6,
    isHot: true,
  },
  {
    id: 5,
    name: 'Samsung 55" 4K Smart TV',
    image: '📺',
    originalPrice: 85000,
    currentPrice: 72000,
    store: 'Daraz',
    discount: 15,
    rating: 4.5,
  },
  {
    id: 6,
    name: 'iPhone 15 Pro Max 256GB',
    image: '📱',
    originalPrice: 199999,
    currentPrice: 185000,
    store: 'Pickaboo',
    discount: 8,
    rating: 4.9,
    isNew: true,
  },
];

export default function TrendingDeals() {
  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="section-title flex items-center gap-2">
            🔥 Trending Deals
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Best discounts right now</p>
        </div>
        <a href="/deals" className="text-sm text-primary font-medium hover:underline">
          View All →
        </a>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4">
        {trendingDeals.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.05 }}
          >
            <ProductCard product={product} />
          </motion.div>
        ))}
      </div>
    </section>
  );
}
