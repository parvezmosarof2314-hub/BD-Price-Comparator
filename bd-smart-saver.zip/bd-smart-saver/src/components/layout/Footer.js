'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="hidden md:block bg-secondary-700 dark:bg-secondary-800 text-gray-300 border-t border-secondary-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">BS</span>
              </div>
              <span className="font-bold text-lg text-white">BD Smart Saver</span>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              AI-powered price comparison platform for Bangladesh. Find the best deals, cheaper alternatives, and save money on every purchase.
            </p>
            <p className="text-sm text-gray-500">
              বাংলাদেশের সেরা প্রাইস কম্পেয়ারিজন প্ল্যাটফর্ম
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/search" className="hover:text-primary transition-colors">Search Products</Link></li>
              <li><Link href="/deals" className="hover:text-primary transition-colors">Today's Deals</Link></li>
              <li><Link href="/categories" className="hover:text-primary transition-colors">Categories</Link></li>
              <li><Link href="/wishlist" className="hover:text-primary transition-colors">My Wishlist</Link></li>
            </ul>
          </div>

          {/* Supported Stores */}
          <div>
            <h4 className="font-semibold text-white mb-4">Supported Stores</h4>
            <ul className="space-y-2 text-sm">
              <li>Daraz Bangladesh</li>
              <li>Star Tech</li>
              <li>Ryans Computers</li>
              <li>Pickaboo</li>
              <li>AjkerDeal</li>
              <li>Gadget & Gear</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-white mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li>📧 support@bdsmartsaver.com</li>
              <li>📱 +880 1XXX-XXXXXX</li>
              <li>📍 Dhaka, Bangladesh</li>
            </ul>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-8 h-8 bg-secondary-600 rounded-lg flex items-center justify-center hover:bg-primary transition-colors">
                <span className="text-xs">FB</span>
              </a>
              <a href="#" className="w-8 h-8 bg-secondary-600 rounded-lg flex items-center justify-center hover:bg-primary transition-colors">
                <span className="text-xs">YT</span>
              </a>
              <a href="#" className="w-8 h-8 bg-secondary-600 rounded-lg flex items-center justify-center hover:bg-primary transition-colors">
                <span className="text-xs">TG</span>
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-secondary-500 mt-8 pt-8 text-center text-sm text-gray-500">
          <p>© 2024 BD Smart Saver. All rights reserved. | Made with ❤️ in Bangladesh</p>
        </div>
      </div>
    </footer>
  );
}
