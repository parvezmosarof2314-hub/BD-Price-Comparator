'use client';

import { motion } from 'framer-motion';

export default function ProductCard({ product }) {
  const { name, image, originalPrice, currentPrice, store, discount, rating, isHot, isNew } = product;

  const formatPrice = (price) => {
    return '৳' + price.toLocaleString('en-BD');
  };

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="card card-hover p-3 cursor-pointer group relative"
    >
      {/* Badges */}
      <div className="absolute top-2 left-2 z-10 flex flex-col gap-1">
        {isHot && (
          <span className="badge-hot text-[10px]">🔥 HOT</span>
        )}
        {isNew && (
          <span className="badge bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 text-[10px]">✨ NEW</span>
        )}
        {discount > 0 && (
          <span className="badge bg-red-500 text-white text-[10px]">-{discount}%</span>
        )}
      </div>

      {/* Wishlist Button */}
      <button className="absolute top-2 right-2 z-10 w-7 h-7 rounded-full bg-white/80 dark:bg-secondary-600/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
        <svg className="w-4 h-4 text-gray-400 hover:text-red-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 0 0 0 6.364L12 20.364l7.682-7.682a4.5 4.5 0 0 0-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 0 0-6.364 0z" />
        </svg>
      </button>

      {/* Product Image */}
      <div className="aspect-square bg-gray-50 dark:bg-secondary-700 rounded-xl flex items-center justify-center mb-3 overflow-hidden">
        <span className="text-4xl group-hover:scale-110 transition-transform duration-300">{image}</span>
      </div>

      {/* Product Info */}
      <div className="space-y-1.5">
        <h3 className="text-xs font-medium text-gray-800 dark:text-gray-200 line-clamp-2 leading-tight">
          {name}
        </h3>

        {/* Store */}
        <p className="text-[10px] text-gray-400">{store}</p>

        {/* Rating */}
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-accent">★</span>
          <span className="text-[10px] text-gray-500">{rating}</span>
        </div>

        {/* Price */}
        <div className="space-y-0.5">
          <div className="text-sm font-bold text-primary">
            {formatPrice(currentPrice)}
          </div>
          {originalPrice > currentPrice && (
            <div className="text-[10px] text-gray-400 line-through">
              {formatPrice(originalPrice)}
            </div>
          )}
        </div>

        {/* Compare Button */}
        <button className="w-full mt-2 py-1.5 text-[10px] font-medium text-primary border border-primary/30 rounded-lg hover:bg-primary hover:text-white transition-all duration-300">
          Compare Prices
        </button>
      </div>
    </motion.div>
  );
}
