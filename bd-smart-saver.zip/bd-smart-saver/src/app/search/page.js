'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import ProductCard from '../../components/common/ProductCard';

const mockResults = [
  { id: 1, name: 'iPhone 15 Pro Max 256GB', image: '📱', originalPrice: 199999, currentPrice: 185000, store: 'Pickaboo', discount: 8, rating: 4.9, isHot: true },
  { id: 2, name: 'iPhone 15 Pro 128GB', image: '📱', originalPrice: 175000, currentPrice: 165000, store: 'Star Tech', discount: 6, rating: 4.8 },
  { id: 3, name: 'iPhone 15 128GB', image: '📱', originalPrice: 139999, currentPrice: 129999, store: 'Daraz', discount: 7, rating: 4.7 },
  { id: 4, name: 'iPhone 15 Plus 256GB', image: '📱', originalPrice: 159999, currentPrice: 149999, store: 'Ryans', discount: 6, rating: 4.6 },
  { id: 5, name: 'Samsung Galaxy S24 Ultra', image: '📱', originalPrice: 159999, currentPrice: 139999, store: 'Star Tech', discount: 12, rating: 4.8, isNew: true },
  { id: 6, name: 'Google Pixel 8 Pro', image: '📱', originalPrice: 115000, currentPrice: 99999, store: 'Gadget & Gear', discount: 13, rating: 4.7 },
];

const stores = ['All Stores', 'Daraz', 'Star Tech', 'Ryans', 'Pickaboo', 'AjkerDeal', 'Gadget & Gear'];
const sortOptions = ['Relevance', 'Price: Low to High', 'Price: High to Low', 'Rating', 'Discount'];

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [selectedStore, setSelectedStore] = useState('All Stores');
  const [sortBy, setSortBy] = useState('Relevance');
  const [results, setResults] = useState(mockResults);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const q = params.get('q');
    if (q) setQuery(q);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Search Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1 relative">
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="m21 21-6-6m2-5a7 7 0 1 1-14 0 7 7 0 0 1 14 0z" />
            </svg>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="input-field pl-12"
              placeholder="Search products..."
            />
          </div>
          <button className="btn-primary py-3 px-6">Search</button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          {/* Store Filter */}
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
            {stores.map((store) => (
              <button
                key={store}
                onClick={() => setSelectedStore(store)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                  selectedStore === store
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 dark:bg-secondary-600 text-gray-600 dark:text-gray-300 hover:bg-primary/10'
                }`}
              >
                {store}
              </button>
            ))}
          </div>
        </div>

        {/* Sort & Results Count */}
        <div className="flex items-center justify-between mt-4">
          <p className="text-sm text-gray-500">
            <span className="font-medium text-gray-800 dark:text-white">{results.length}</span> results found
            {query && <span> for "<span className="text-primary">{query}</span>"</span>}
          </p>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="text-xs bg-gray-100 dark:bg-secondary-600 border-none rounded-lg px-3 py-2 text-gray-600 dark:text-gray-300"
          >
            {sortOptions.map((opt) => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>
        </div>
      </motion.div>

      {/* AI Suggestion Box */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-6 p-4 bg-primary/5 dark:bg-primary/10 border border-primary/20 rounded-xl"
      >
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-sm">🤖</span>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-800 dark:text-white">AI Shopping Advisor</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Based on current market trends, prices for this category are expected to drop by 5-10% during the upcoming sale season. 
              <span className="text-primary font-medium"> Consider waiting 2 weeks for better deals.</span>
            </p>
          </div>
        </div>
      </motion.div>

      {/* Results Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
        {results.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <ProductCard product={product} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}
