'use client';

import { motion } from 'framer-motion';

const stats = [
  { label: 'Total Users', value: '12,847', change: '+12%', icon: '👥', color: 'bg-blue-500' },
  { label: 'Products Tracked', value: '52,340', change: '+8%', icon: '📦', color: 'bg-green-500' },
  { label: 'Price Alerts Sent', value: '3,421', change: '+24%', icon: '🔔', color: 'bg-yellow-500' },
  { label: 'Stores Connected', value: '8', change: '+1', icon: '🏪', color: 'bg-purple-500' },
];

const recentActivity = [
  { action: 'New user registered', user: 'Rahim Ahmed', time: '2 min ago' },
  { action: 'Price alert triggered', product: 'iPhone 15 Pro', time: '5 min ago' },
  { action: 'New deal detected', store: 'Daraz', time: '12 min ago' },
  { action: 'Product added', product: 'Samsung S24 FE', time: '20 min ago' },
  { action: 'Fake discount flagged', store: 'AjkerDeal', time: '35 min ago' },
];

export default function AdminPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
        <p className="text-sm text-gray-500">Overview of BD Smart Saver platform</p>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card p-4"
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 ${stat.color} rounded-xl flex items-center justify-center`}>
                <span className="text-lg">{stat.icon}</span>
              </div>
              <div>
                <p className="text-xs text-gray-400">{stat.label}</p>
                <p className="text-lg font-bold text-gray-900 dark:text-white">{stat.value}</p>
                <p className="text-[10px] text-green-500 font-medium">{stat.change}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Admin Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="card p-5"
        >
          <h3 className="text-sm font-semibold text-gray-800 dark:text-white mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-secondary-700 transition-colors">
                <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-xs text-gray-700 dark:text-gray-300">{activity.action}</p>
                  <p className="text-[10px] text-gray-400">{activity.user || activity.product || activity.store}</p>
                </div>
                <span className="text-[10px] text-gray-400">{activity.time}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="card p-5"
        >
          <h3 className="text-sm font-semibold text-gray-800 dark:text-white mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Manage Products', icon: '📦', desc: 'Add/Edit products' },
              { label: 'Manage Stores', icon: '🏪', desc: 'Store settings' },
              { label: 'User Management', icon: '👥', desc: 'View users' },
              { label: 'Analytics', icon: '📊', desc: 'View reports' },
              { label: 'Price Scraper', icon: '🔄', desc: 'Run scraper' },
              { label: 'AI Settings', icon: '🤖', desc: 'Configure AI' },
            ].map((action) => (
              <button
                key={action.label}
                className="p-3 rounded-xl bg-gray-50 dark:bg-secondary-700 hover:bg-primary/5 dark:hover:bg-primary/10 transition-colors text-left"
              >
                <span className="text-lg">{action.icon}</span>
                <p className="text-xs font-medium text-gray-800 dark:text-gray-200 mt-1">{action.label}</p>
                <p className="text-[10px] text-gray-400">{action.desc}</p>
              </button>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
