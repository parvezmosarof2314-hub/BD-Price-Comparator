'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const mockWishlist = [
  { id: 1, name: 'MacBook Air M3', icon: '💻', targetPrice: 155000, currentPrice: 162000, store: 'Star Tech', status: 'above' },
  { id: 2, name: 'Sony WH-1000XM5', icon: '🎧', targetPrice: 34000, currentPrice: 35500, store: 'Ryans', status: 'close' },
  { id: 3, name: 'iPhone 15 Pro', icon: '📱', targetPrice: 170000, currentPrice: 185000, store: 'Pickaboo', status: 'above' },
  { id: 4, name: 'Samsung Galaxy Watch 6', icon: '⌚', targetPrice: 28000, currentPrice: 26500, store: 'Daraz', status: 'reached' },
];

export default function WishlistPage() {
  const [wishlist, setWishlist] = useState(mockWishlist);

  const getStatusColor = (status) => {
    switch (status) {
      case 'reached': return 'text-green-500 bg-green-50 dark:bg-green-900/20';
      case 'close': return 'text-yellow-500 bg-yellow-50 dark:bg-yellow-900/20';
      case 'above': return 'text-red-500 bg-red-50 dark:bg-red-900/20';
      default: return 'text-gray-500 bg-gray-50';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'reached': return '✅ Price Reached!';
      case 'close': return '🔔 Almost There';
      case 'above': return '⏳ Waiting';
      default: return 'Unknown';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">My Wishlist</h1>
        <p className="text-sm text-gray-500 mb-6">Get notified when prices drop to your target</p>
      </motion.div>

      {/* Add Alert */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="card p-4 mb-6"
      >
        <div className="flex items-center gap-3">
          <input
            type="text"
            placeholder="Add product to watch..."
            className="input-field flex-1"
          />
          <input
            type="number"
            placeholder="Target ৳"
            className="input-field w-32"
          />
          <button className="btn-primary py-3 px-4 whitespace-nowrap text-sm">
            + Add Alert
          </button>
        </div>
      </motion.div>

      {/* Wishlist Items */}
      <div className="space-y-3">
        <AnimatePresence>
          {wishlist.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ delay: index * 0.08 }}
              className="card p-4"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gray-50 dark:bg-secondary-700 flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">{item.icon}</span>
                </div>

                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-gray-800 dark:text-gray-200">{item.name}</h4>
                  <p className="text-xs text-gray-400">{item.store}</p>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-xs text-gray-500">Target: <span className="font-medium text-primary">৳{item.targetPrice.toLocaleString()}</span></span>
                    <span className="text-xs text-gray-500">Current: <span className="font-medium">৳{item.currentPrice.toLocaleString()}</span></span>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <span className={`text-[10px] font-medium px-2 py-1 rounded-full ${getStatusColor(item.status)}`}>
                    {getStatusText(item.status)}
                  </span>
                  <button className="text-xs text-red-400 hover:text-red-500">Remove</button>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
