'use client';

import HeroSection from '../components/home/HeroSection';
import SearchSection from '../components/home/SearchSection';
import TrendingDeals from '../components/home/TrendingDeals';
import CheapestToday from '../components/home/CheapestToday';
import AIRecommendations from '../components/home/AIRecommendations';
import PopularCategories from '../components/home/PopularCategories';
import PriceDropAlerts from '../components/home/PriceDropAlerts';
import StoresSection from '../components/home/StoresSection';

export default function Home() {
  return (
    <div className="space-y-0">
      <HeroSection />
      <SearchSection />
      <TrendingDeals />
      <CheapestToday />
      <AIRecommendations />
      <PopularCategories />
      <PriceDropAlerts />
      <StoresSection />
    </div>
  );
}
