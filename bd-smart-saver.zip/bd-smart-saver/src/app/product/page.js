'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';

const mockProduct = {
  name: 'iPhone 15 Pro Max 256GB',
  brand: 'Apple',
  category: 'Smartphones',
  image: '📱',
  rating: 4.9,
  reviews: 234,
  specs: {
    Display: '6.7" Super Retina XDR OLED',
    Processor: 'A17 Pro Chip',
    RAM: '8GB',
    Storage: '256GB',
    Camera: '48MP + 12MP + 12MP',
    Battery: '4422 mAh',
  },
  prices: [
    { store: 'Pickaboo', price: 185000, inStock: true, delivery: 'Free', rating: 4.5 },
    { store: 'Star Tech', price: 189000, inStock: true, delivery: '৳60', rating: 4.7 },
    { store: 'Daraz', price: 187000, inStock: true, delivery: 'Free', rating: 4.2 },
    { store: 'Ryans Computers', price: 191000, inStock: false, delivery: '৳100', rating: 4.6 },
    { store: 'Gadget & Gear', price: 188500, inStock: true, delivery: '৳80', rating: 4.4 },
  ],
  priceHistory: [
    { date: '2024-01', price: 199000 },
    { date: '2024-02', price: 195000 },
    { date: '2024-03', price: 192000 },
    { date: '2024-04', price: 189000 },
    { date: '2024-05', price: 185000 },
  ],
  alternatives: [
    { name: 'Samsung Galaxy S24 Ultra', price: 139999, match: '92%' },
    { name: 'Google Pixel 8 Pro', price: 99999, match: '85%' },
    { name: 'OnePlus 12', price: 89999, match: '80%' },
  ],
};

export default function ProductPage() {
  const [product] = useState(mockProduct);
  const lowestPrice = Math.min(...product.prices.filter(p => p.inStock).map(p => p.price));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Product Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="card p-6"
      >
        <div className="flex flex-col md:flex-row gap-6">
          {/* Image */}
          <div className="w-full md:w-48 h-48 bg-gray-50 dark:bg-secondary-700 rounded-xl flex items-center justify-center">
            <span className="text-7xl">{product.image}</span>
          </div>

          {/* Info */}
          <div className="flex-1 space-y-3">
            <div>
              <p className="text-xs text-primary font-medium">{product.brand} • {product.category}</p>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white mt-1">{product.name}</h1>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-accent">★</span>
              <span className="text-sm font-medium">{product.rating}</span>
              <span className="text-xs text-gray-400">({product.reviews} reviews)</span>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-bold text-primary">৳{lowestPrice.toLocaleString()}</span>
              <span className="text-sm text-gray-400">Lowest price from {product.prices.length} stores</span>
            </div>

            <div className="flex gap-2">
              <button className="btn-primary text-sm py-2 px-4">🛒 Buy at Best Price</button>
              <button className="btn-secondary text-sm py-2 px-4">❤️ Add to Wishlist</button>
              <button className="btn-secondary text-sm py-2 px-4">🔔 Price Alert</button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Price Comparison Table */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="card p-5"
      >
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">💰 Price Comparison</h2>
        <div className="space-y-2">
          {product.prices
            .sort((a, b) => a.price - b.price)
            .map((store, index) => (
              <div
                key={store.store}
                className={`flex items-center justify-between p-3 rounded-xl transition-colors ${
                  index === 0 ? 'bg-primary/5 border border-primary/20' : 'bg-gray-50 dark:bg-secondary-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  {index === 0 && <span className="text-xs bg-primary text-white px-2 py-0.5 rounded-full">Best</span>}
                  <div>
                    <p className="text-sm font-medium text-gray-800 dark:text-gray-200">{store.store}</p>
                    <p className="text-[10px] text-gray-400">
                      Delivery: {store.delivery} • Rating: ★{store.rating}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-sm font-bold ${index === 0 ? 'text-primary' : 'text-gray-700 dark:text-gray-300'}`}>
                    ৳{store.price.toLocaleString()}
                  </span>
                  {store.inStock ? (
                    <span className="text-[10px] text-green-500 bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded-full">In Stock</span>
                  ) : (
                    <span className="text-[10px] text-red-500 bg-red-50 dark:bg-red-900/20 px-2 py-0.5 rounded-full">Out of Stock</span>
                  )}
                  <button className="text-xs text-primary font-medium hover:underline">Visit →</button>
                </div>
              </div>
            ))}
        </div>
      </motion.div>

      {/* Specifications */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="card p-5"
      >
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">📋 Specifications</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {Object.entries(product.specs).map(([key, value]) => (
            <div key={key} className="flex items-center gap-3 p-2.5 rounded-lg bg-gray-50 dark:bg-secondary-700">
              <span className="text-xs font-medium text-gray-500 w-24">{key}</span>
              <span className="text-xs text-gray-800 dark:text-gray-200">{value}</span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* AI Alternatives */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="card p-5"
      >
        <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">🤖 AI Cheaper Alternatives</h2>
        <div className="space-y-2">
          {product.alternatives.map((alt) => (
            <div key={alt.name} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-secondary-700 hover:bg-primary/5 dark:hover:bg-primary/5 transition-colors cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <span className="text-xs font-bold text-primary">{alt.match}</span>
                </div>
                <span className="text-sm font-medium text-gray-800 dark:text-gray-200">{alt.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-bold text-primary">৳{alt.price.toLocaleString()}</span>
                <span className="text-[10px] text-green-500">
                  Save ৳{(lowestPrice - alt.price).toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
