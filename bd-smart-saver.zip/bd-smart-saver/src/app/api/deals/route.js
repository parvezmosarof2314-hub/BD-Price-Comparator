import { NextResponse } from 'next/server';

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type') || 'all'; // flash, coupon, pricedrop
  const store = searchParams.get('store') || 'all';

  try {
    const deals = getMockDeals(type, store);

    return NextResponse.json({
      success: true,
      data: deals,
      meta: {
        totalDeals: deals.length,
        lastUpdated: new Date().toISOString(),
      }
    });
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

function getMockDeals(type, store) {
  const allDeals = [
    {
      id: 1,
      type: 'flash',
      product: 'Xiaomi 14 Ultra',
      originalPrice: 125000,
      dealPrice: 99999,
      store: 'Daraz',
      discount: 20,
      expiresAt: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
      isVerified: true,
    },
    {
      id: 2,
      type: 'coupon',
      store: 'Star Tech',
      code: 'TECH10',
      discountType: 'percentage',
      discountValue: 10,
      minOrder: 10000,
      expiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 3,
      type: 'pricedrop',
      product: 'AirPods Pro 2',
      oldPrice: 35000,
      newPrice: 29999,
      store: 'Pickaboo',
      dropPercentage: 14,
      detectedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    },
  ];

  let filtered = allDeals;
  if (type !== 'all') filtered = filtered.filter(d => d.type === type);
  if (store !== 'all') filtered = filtered.filter(d => d.store.toLowerCase() === store.toLowerCase());

  return filtered;
}
