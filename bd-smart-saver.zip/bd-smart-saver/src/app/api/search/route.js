import { NextResponse } from 'next/server';

// Mock product database - In production, this would query MongoDB
const products = [
  { id: 1, name: 'iPhone 15 Pro Max', category: 'smartphones', prices: [{ store: 'Pickaboo', price: 185000 }, { store: 'Star Tech', price: 189000 }, { store: 'Daraz', price: 187000 }] },
  { id: 2, name: 'Samsung Galaxy S24 Ultra', category: 'smartphones', prices: [{ store: 'Star Tech', price: 139999 }, { store: 'Ryans', price: 142000 }, { store: 'Daraz', price: 141000 }] },
  { id: 3, name: 'MacBook Air M3', category: 'laptops', prices: [{ store: 'Star Tech', price: 162000 }, { store: 'Ryans', price: 165000 }, { store: 'Pickaboo', price: 163000 }] },
];

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('q')?.toLowerCase() || '';
  const store = searchParams.get('store') || 'all';
  const sort = searchParams.get('sort') || 'relevance';
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '20');

  try {
    // Filter products by search query
    let results = products.filter(product =>
      product.name.toLowerCase().includes(query) ||
      product.category.toLowerCase().includes(query)
    );

    // Filter by store
    if (store !== 'all') {
      results = results.filter(product =>
        product.prices.some(p => p.store.toLowerCase() === store.toLowerCase())
      );
    }

    // Sort results
    if (sort === 'price_low') {
      results.sort((a, b) => Math.min(...a.prices.map(p => p.price)) - Math.min(...b.prices.map(p => p.price)));
    } else if (sort === 'price_high') {
      results.sort((a, b) => Math.min(...b.prices.map(p => p.price)) - Math.min(...a.prices.map(p => p.price)));
    }

    // Pagination
    const startIndex = (page - 1) * limit;
    const paginatedResults = results.slice(startIndex, startIndex + limit);

    return NextResponse.json({
      success: true,
      data: paginatedResults,
      pagination: {
        page,
        limit,
        total: results.length,
        totalPages: Math.ceil(results.length / limit)
      },
      query
    });
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
