'use client';

import '../styles/globals.css';
import { ThemeProvider } from '../context/ThemeContext';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import MobileNav from '../components/layout/MobileNav';
import { Toaster } from 'react-hot-toast';

export default function RootLayout({ children }) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <title>BD Smart Saver - AI Price Comparison Bangladesh</title>
        <meta name="description" content="Find cheaper alternatives and best deals for any product in Bangladesh. AI-powered price comparison from Daraz, Star Tech, Ryans, Pickaboo and more." />
        <meta name="keywords" content="price comparison bangladesh, cheap products bd, daraz deals, best price finder, bd smart saver" />
      </head>
      <body className="bg-white dark:bg-secondary-700 text-gray-900 dark:text-white transition-colors duration-300">
        <ThemeProvider>
          <Toaster position="top-center" />
          <Navbar />
          <main className="min-h-screen pt-16 pb-20 md:pb-0">
            {children}
          </main>
          <Footer />
          <MobileNav />
        </ThemeProvider>
      </body>
    </html>
  );
}
