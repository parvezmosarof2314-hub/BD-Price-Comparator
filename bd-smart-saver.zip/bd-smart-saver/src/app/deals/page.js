'use client';

import { motion } from 'framer-motion';
import ProductCard from '../../components/common/ProductCard';

const flashDeals = [
  { id: 1, name: 'Xiaomi 14 Ultra', image: '📱', originalPrice: 125000, currentPrice: 99999, store: 'Daraz', discount: 20, rating: 4.7, isHot: true },
  { id: 2, name: 'Sony WF-1000XM5', image: '🎧', originalPrice: 32000, currentPrice: 25999, store: 'Star Tech', discount: 19, rating: 4.9, isHot: true },
  { id: 3, name: 'iPad Air M2', image: '📱', originalPrice: 95000, currentPrice: 82000, store: 'Pickaboo', discount: 14, rating: 4.8 },
  { id: 4, name: 'Razer DeathAdder V3', image: '🖱️', originalPrice: 9500, currentPrice: 7500, store: 'Ryans', discount: 21, rating: 4.6, isHot: true },
];

const coupons = [
  { id: 1, store: 'Daraz', code: 'SAVE500', discount: '৳500 Off', minOrder: '৳5000+', expires: '3 days' },
  { id: 2, store: 'Star Tech', code: 'TECH10', discount: '10% Off', minOrder: '৳10000+', expires: '5 days' },
  { id: 3, store: 'Pickaboo', code: 'PIKA200', discount: '৳200 Off', minOrder: '৳2000+', expires: '2 days' },
  { id: 4, store: 'AjkerDeal', code: 'AJKER15', discount: '15% Off', minOrder: '৳3000+', expires: '7 days' },
];

export default function DealsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-10">
      {/* Flash Deals */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              ⚡ Flash Deals
            </h2>
            <p className="text-sm text-gray-500 mt-1">Limited time offers - grab them fast!</p>
          </div>
          <div className="flex items-center gap-2 bg-red-50 dark:bg-red-900/20 px-3 py-1.5 rounded-lg">
            <span className="text-xs font-medium text-red-600 dark:text-red-400">Ends in:</span>
            <span className="text-sm font-bold text-red-600 dark:text-red-400">04:32:15</span>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {flashDeals.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <ProductCard product={product} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Coupons */}
      <section>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
          🎟️ Active Coupons
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {coupons.map((coupon, index) => (
            <motion.div
              key={coupon.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.08 }}
              className="card p-4 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-16 h-16 bg-primary/5 rounded-bl-full" />
              <div className="space-y-2">
                <p className="text-xs text-gray-400">{coupon.store}</p>
                <p className="text-lg font-bold text-primary">{coupon.discount}</p>
                <p className="text-xs text-gray-500">Min. order: {coupon.minOrder}</p>
                <div className="flex items-center justify-between pt-2 border-t border-gray-100 dark:border-secondary-500">
                  <code className="text-xs font-mono bg-gray-100 dark:bg-secondary-700 px-2 py-1 rounded">
                    {coupon.code}
                  </code>
                  <span className="text-[10px] text-red-500">{coupon.expires} left</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Fake Discount Warning */}
      <section>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="p-5 bg-accent/5 border border-accent/20 rounded-xl"
        >
          <div className="flex items-start gap-3">
            <span className="text-2xl">⚠️</span>
            <div>
              <h3 className="text-sm font-semibold text-gray-800 dark:text-white">AI Fake Discount Detection</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Our AI has detected <span className="font-medium text-red-500">12 products</span> with manipulated pricing today. 
                We flag products where sellers inflate original prices to show fake discounts. 
                All deals shown here are verified genuine discounts.
              </p>
            </div>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
