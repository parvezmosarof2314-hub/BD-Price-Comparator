'use client';

import { motion } from 'framer-motion';

const allCategories = [
  { id: 1, name: 'Smartphones', nameBn: 'স্মার্টফোন', icon: '📱', count: 2450, subcategories: ['iPhone', 'Samsung', 'Xiaomi', 'Realme', 'OnePlus'] },
  { id: 2, name: 'Laptops', nameBn: 'ল্যাপটপ', icon: '💻', count: 1230, subcategories: ['Gaming', 'Business', 'Student', 'Ultrabook'] },
  { id: 3, name: 'Headphones & Audio', nameBn: 'হেডফোন ও অডিও', icon: '🎧', count: 890, subcategories: ['Wireless', 'Wired', 'TWS', 'Speakers'] },
  { id: 4, name: 'Gaming', nameBn: 'গেমিং', icon: '🎮', count: 670, subcategories: ['Mouse', 'Keyboard', 'Monitor', 'Console'] },
  { id: 5, name: 'Smart Watches', nameBn: 'স্মার্ট ওয়াচ', icon: '⌚', count: 540, subcategories: ['Apple Watch', 'Samsung', 'Amazfit', 'Fitness Band'] },
  { id: 6, name: 'Cameras', nameBn: 'ক্যামেরা', icon: '📷', count: 320, subcategories: ['DSLR', 'Mirrorless', 'Action Cam', 'Webcam'] },
  { id: 7, name: 'TV & Display', nameBn: 'টিভি ও ডিসপ্লে', icon: '📺', count: 450, subcategories: ['Smart TV', 'Monitor', 'Projector'] },
  { id: 8, name: 'Accessories', nameBn: 'এক্সেসরিজ', icon: '🔌', count: 1800, subcategories: ['Charger', 'Cable', 'Case', 'Power Bank'] },
  { id: 9, name: 'Home Appliances', nameBn: 'গৃহস্থালী', icon: '🏠', count: 960, subcategories: ['AC', 'Refrigerator', 'Washing Machine', 'Fan'] },
  { id: 10, name: 'Health & Fitness', nameBn: 'স্বাস্থ্য', icon: '💪', count: 430, subcategories: ['Protein', 'Supplements', 'Equipment'] },
  { id: 11, name: 'Networking', nameBn: 'নেটওয়ার্কিং', icon: '📡', count: 280, subcategories: ['Router', 'Switch', 'Access Point'] },
  { id: 12, name: 'Storage', nameBn: 'স্টোরেজ', icon: '💾', count: 520, subcategories: ['SSD', 'HDD', 'Pen Drive', 'Memory Card'] },
];

export default function CategoriesPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">All Categories</h1>
        <p className="text-sm text-gray-500 mt-1">Browse products by category to find the best prices</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {allCategories.map((category, index) => (
          <motion.div
            key={category.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ scale: 1.01 }}
            className="card p-5 cursor-pointer"
          >
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-3xl">{category.icon}</span>
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-gray-800 dark:text-white">{category.name}</h3>
                <p className="text-xs text-gray-400 font-bangla">{category.nameBn}</p>
                <p className="text-xs text-primary mt-1">{category.count.toLocaleString()} products</p>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {category.subcategories.map((sub) => (
                    <span key={sub} className="text-[10px] px-2 py-0.5 rounded-full bg-gray-100 dark:bg-secondary-700 text-gray-500 dark:text-gray-400">
                      {sub}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
